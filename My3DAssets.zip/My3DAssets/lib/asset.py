# ##### BEGIN GPL LICENSE BLOCK #####
#
#  THREEDPFonts asset management toolkit for Blender.
#  Copyright (C) 2015-2019  Mikhail Rachinskiy + Paul Summers
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####


import os
from math import tau, sin, cos
from functools import lru_cache

import bpy
from mathutils import Matrix, Vector, kdtree

from . import mesh, unit
from .. import var


# Gem
# ------------------------------------

def get_name(x):
    return x.replace("_", " ").title()


@lru_cache(maxsize=128)
def girdle_coords(radius, mat):
    coords = []
    app = coords.append
    angle = tau / 64

    for i in range(64):
        x = sin(i * angle) * radius
        y = cos(i * angle) * radius
        app(Vector((x, y, 0.0)))

    return tuple((mat @ co).freeze() for co in coords)


@lru_cache(maxsize=128)
def find_nearest(loc1, rad1, coords1, coords2):
    proximity = []
    app = proximity.append

    for co2 in coords2:
        app(((co2 - loc1).length, co2))
    dis, co2 = min(proximity, key=lambda x: x[0])

    if dis < rad1:
        return dis - rad1, co2, co2

    proximity.clear()

    for co1 in coords1:
        app(((co1 - co2).length, co1))
    dis, co1 = min(proximity, key=lambda x: x[0])

    return dis, co1, co2

def to_int(x):
    if x.is_integer():
        return int(x)
    return x


# Material
# ------------------------------------


def color_rnd():
    import random
    seq = (0.0, 0.5, 1.0)
    return random.choice(seq), random.choice(seq), random.choice(seq), 1.0


def add_material(ob, name="New Material", color=None, is_gem=False):
    mat = bpy.data.materials.get(name)

    if not mat:
        mat = bpy.data.materials.new(name)
        mat.diffuse_color = color

        if bpy.context.scene.render.engine in {"CYCLES", "BLENDER_EEVEE"}:
            mat.use_nodes = True
            nodes = mat.node_tree.nodes

            for node in nodes:
                nodes.remove(node)

            if is_gem:
                node = nodes.new("ShaderNodeBsdfGlass")
                node.inputs["Color"].default_value = color
            else:
                node = nodes.new("ShaderNodeBsdfPrincipled")
                node.inputs["Base Color"].default_value = color
                node.inputs["Metallic"].default_value = 1.0
                node.inputs["Roughness"].default_value = 0.0

            node.location = (0.0, 0.0)

            node_out = nodes.new("ShaderNodeOutputMaterial")
            node_out.location = (400.0, 0.0)

            mat.node_tree.links.new(node.outputs["BSDF"], node_out.inputs["Surface"])

    if ob.material_slots:
        ob.material_slots[0].material = mat
    else:
        ob.data.materials.append(mat)


# Asset
# ------------------------------------


def user_asset_asset_library_folder_object():
    prefs = bpy.context.preferences.addons[var.ADDON_ID].preferences

    if prefs.use_custom_asset_asset_dir:
        return bpy.path.abspath(prefs.custom_asset_asset_dir)

    return var.USER_ASSET_DIR_OBJECT


def user_asset_asset_library_folder_weighting():
    prefs = bpy.context.preferences.addons[var.ADDON_ID].preferences

    if prefs.weighting_set_use_custom_dir:
        return bpy.path.abspath(prefs.weighting_set_custom_dir)

    return var.USER_ASSET_DIR_WEIGHTING


def asset_import(filepath="", ob_name=False, me_name=False):

    with bpy.data.libraries.load(filepath) as (data_from, data_to):

        if ob_name:
            data_to.objects = [ob_name]

        if me_name:
            data_to.meshes = [me_name]

    return data_to


def asset_import_batch(filepath=""):

    with bpy.data.libraries.load(filepath) as (data_from, data_to):
        data_to.objects = data_from.objects

    return data_to


def asset_export(folder="", filename=""):
    filepath = os.path.join(folder, filename)
    data_blocks = set(bpy.context.selected_objects)

    if not os.path.exists(folder):
        os.makedirs(folder)

    bpy.data.libraries.write(filepath, data_blocks, compress=True)


def render_preview(width, height, filepath="//", compression=100):
    render = bpy.context.scene.render
    image = render.image_settings

    # Apply settings
    # ---------------------------

    settings_render = {
        "filepath": filepath,
        "resolution_x": width,
        "resolution_y": height,
        "resolution_percentage": 100,
        "film_transparent": True,
    }

    settings_image = {
        "file_format": "PNG",
        "color_mode": "RGBA",
        "compression": compression,
    }

    for k, v in settings_render.items():
        x = getattr(render, k)
        setattr(render, k, v)
        settings_render[k] = x

    for k, v in settings_image.items():
        x = getattr(image, k)
        setattr(image, k, v)
        settings_image[k] = x

    # Render and save
    # ---------------------------

    bpy.ops.render.opengl(write_still=True)

    # Revert settings
    # ---------------------------

    for k, v in settings_render.items():
        setattr(render, k, v)

    for k, v in settings_image.items():
        setattr(image, k, v)


def show_window(width, height, area_type=None, space_data=None):
    render = bpy.context.scene.render

    # Apply settings
    # ---------------------------

    settings_render = {
        "resolution_x": width,
        "resolution_y": height,
        "resolution_percentage": 100,
        "display_mode": "WINDOW",
    }

    for k, v in settings_render.items():
        x = getattr(render, k)
        setattr(render, k, v)
        settings_render[k] = x

    # Invoke window
    # ---------------------------

    bpy.ops.render.view_show("INVOKE_DEFAULT")

    # Set window
    # ---------------------------

    area = bpy.context.window_manager.windows[-1].screen.areas[0]

    if area_type is not None:
        area.type = area_type

    if space_data is not None:
        space = area.spaces[0]
        for k, v in space_data.items():
            setattr(space, k, v)

    # Revert settings
    # ---------------------------

    for k, v in settings_render.items():
        setattr(render, k, v)


# Object
# ------------------------------------


def bm_to_scene(bm, name="New object", color=None):
    space_data = bpy.context.space_data
    use_local_view = bool(space_data.local_view)

    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()

    for parent in bpy.context.selected_objects:

        ob = bpy.data.objects.new(name, me)

        for coll in parent.users_collection:
            coll.objects.link(ob)

        if use_local_view:
            ob.local_view_set(space_data, True)

        ob.location = parent.location
        ob.rotation_euler = parent.rotation_euler
        ob.parent = parent
        ob.matrix_parent_inverse = parent.matrix_basis.inverted()

        add_material(ob, name=name, color=color)


def ob_copy_and_parent(ob, parents):
    is_orig = True
    space_data = bpy.context.space_data
    use_local_view = bool(space_data.local_view)

    for parent in parents:
        if is_orig:
            ob_copy = ob
            is_orig = False
        else:
            ob_copy = ob.copy()

        for coll in parent.users_collection:
            coll.objects.link(ob_copy)

        if use_local_view:
            ob_copy.local_view_set(space_data, True)

        ob_copy.select_set(True)
        ob.location = parent.location
        ob.rotation_euler = parent.rotation_euler
        ob.parent = parent
        ob.matrix_parent_inverse = parent.matrix_basis.inverted()


def ob_copy_to_faces(ob):
    mats = mesh.face_pos()

    if mats:
        ob.matrix_world = mats.pop()
        collection = bpy.context.collection
        space_data = bpy.context.space_data
        use_local_view = bool(space_data.local_view)

        for mat in mats:
            ob_copy = ob.copy()
            collection.objects.link(ob_copy)
            ob_copy.matrix_world = mat
            ob_copy.select_set(True)

            if use_local_view:
                ob_copy.local_view_set(space_data, True)


def apply_scale(ob):
    mat = Matrix.Diagonal(ob.scale).to_4x4()
    ob.data.transform(mat)
    ob.scale = (1.0, 1.0, 1.0)


def mod_curve_off(ob, reverse=False):
    """return -> bound box, curve object"""

    mods = reversed(ob.modifiers) if reverse else ob.modifiers

    for mod in mods:
        if mod.type == "CURVE" and mod.object:
            if mod.show_viewport:
                mod.show_viewport = False
                bpy.context.view_layer.update()
                mod.show_viewport = True

            return ob.bound_box, mod.object

    return ob.bound_box, None


def calc_bbox(obs):
    bbox = []

    for ob in obs:
        bbox += [ob.matrix_world @ Vector(x) for x in ob.bound_box]

    x_min = min(x[0] for x in bbox)
    x_max = max(x[0] for x in bbox)
    y_min = min(x[1] for x in bbox)
    y_max = max(x[1] for x in bbox)
    z_min = min(x[2] for x in bbox)
    z_max = max(x[2] for x in bbox)

    x_loc = (x_max + x_min) / 2
    y_loc = (y_max + y_min) / 2
    z_loc = (z_max + z_min) / 2

    x_dim = x_max - x_min
    y_dim = y_max - y_min
    z_dim = z_max - z_min

    return (
        (x_loc, y_loc, z_loc),  # location
        (x_dim, y_dim, z_dim),  # dimensions
        (x_min, y_min, z_min),  # bbox min
        (x_max, y_max, z_max),  # bbox max
    )

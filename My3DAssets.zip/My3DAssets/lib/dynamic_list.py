# ##### BEGIN GPL LICENSE BLOCK #####
#
#  THREEDPFonts asset management toolkit for Blender.
#  Copyright (C) 2015-2019  Mikhail Rachinskiy + Paul Summers
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####


import os

import bpy.utils.previews
from bpy.app.translations import pgettext_iface as _

from .. import var
from . import asset


_cache = {}

# Weighting
# ---------------------------

def weighting_materials(self, context):

    if "weighting_materials__list" in _cache:
        return _cache["weighting_materials__list"]

    props = context.scene.mythreedassets
    list_ = []

    for i, mat in enumerate(props.weighting_materials.values()):
        id_ = str(i)
        name_ = mat.name + " "  # Add trailing space to deny UI translation
        list_.append((id_, name_, ""))

    if not list_:
        list_ = [("", "", "")]

    _cache["weighting_materials__list"] = list_

    return list_


def weighting_set_refresh(self=None, context=None):
    if "weighting_set__list" in _cache:
        del _cache["weighting_set__list"]


def weighting_materials_refresh(self=None, context=None):
    if "weighting_materials__list" in _cache:
        del _cache["weighting_materials__list"]


# Assets
# ---------------------------


def asset_folders(self, context):

    if "asset_folders__list" in _cache:
        return _cache["asset_folders__list"]

    folder = asset.user_asset_asset_library_folder_object()

    if not os.path.exists(folder):
        _cache["asset_folders__list"] = [("", "", "")]
        return [("", "", "")]

    list_ = []

    for entry in os.scandir(folder):

        if entry.is_dir() and not entry.name.startswith("."):
            id_ = entry.name
            name_ = entry.name + " "  # Add trailing space to deny UI translation
            list_.append((id_, name_, ""))

    if not list_:
        list_ = [("", "", "")]

    _cache["asset_folders__list"] = list_

    return list_


def assets(self, context):
    category = context.window_manager.mythreedassets.asset_folder

    if "assets__list" in _cache and category == _cache.get("assets__category"):
        return _cache["assets__list"]

    _cache["assets__category"] = category
    folder = os.path.join(asset.user_asset_asset_library_folder_object(), category)

    if not os.path.exists(folder):
        _cache["assets__list"] = [("", "", "")]
        return [("", "", "")]

    pcoll = var.preview_collections.get("assets")

    if not pcoll:
        pcoll = bpy.utils.previews.new()

    list_ = []
    i = 0
    no_preview = var.preview_collections["icons"]["NO_PREVIEW"].icon_id

    for entry in os.scandir(folder):

        if entry.is_file() and entry.name.endswith(".blend"):
            filename = os.path.splitext(entry.name)[0]
            id_ = filename
            name_ = filename + " "  # Add trailing space to deny UI translation

            preview_id = category + filename
            preview_path = os.path.splitext(entry.path)[0] + ".png"

            if os.path.exists(preview_path):
                if preview_id not in pcoll:
                    pcoll.load(preview_id, preview_path, "IMAGE")
                preview = pcoll[preview_id].icon_id
            else:
                preview = no_preview

            list_.append((id_, name_, "", preview, i))
            i += 1

    var.preview_collections["assets"] = pcoll

    if not pcoll:
        bpy.utils.previews.remove(pcoll)
        del var.preview_collections["assets"]

    if not list_:
        list_ = [("", "", "")]

    _cache["assets__list"] = list_

    return list_


def asset_folder_list_refresh():
    if "asset_folders__list" in _cache:
        del _cache["asset_folders__list"]


def asset_list_refresh(preview_id=False, hard=False):
    pcoll = var.preview_collections.get("assets")

    if pcoll:

        if preview_id and preview_id in pcoll:
            del pcoll[preview_id]

            if not pcoll:
                bpy.utils.previews.remove(pcoll)
                del var.preview_collections["assets"]

        elif hard:
            bpy.utils.previews.remove(pcoll)
            del var.preview_collections["assets"]

    if "assets__list" in _cache:
        del _cache["assets__list"]

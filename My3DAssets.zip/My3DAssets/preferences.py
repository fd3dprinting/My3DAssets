# ##### BEGIN GPL LICENSE BLOCK #####
#
#  MYTHREEDAssets asset management toolkit for Blender.
#  Copyright (C) 2015-2019  Mikhail Rachinskiy + Paul Summers
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####


from bpy.types import PropertyGroup, AddonPreferences, Object
from bpy.props import (
    EnumProperty,
    BoolProperty,
    FloatProperty,
    StringProperty,
    PointerProperty,
    IntProperty,
    FloatVectorProperty,
    CollectionProperty,
)

from .lib import dynamic_list


# Custom properties
# ------------------------------------------


class ListProperty:
    index: IntProperty()

    def add(self):
        item = self.coll.add()
        self.index = len(self.coll) - 1
        return item

    def remove(self):
        if self.coll:
            self.coll.remove(self.index)
            index_last = max(0, len(self.coll) - 1)

            if self.index > index_last:
                self.index = index_last

    def clear(self):
        self.coll.clear()

    def move(self, move_up):

        if len(self.coll) < 2:
            return

        if move_up:
            index_new = self.index - 1
        else:
            index_new = self.index + 1

        if 0 <= index_new < len(self.coll):
            self.coll.move(self.index, index_new)
            self.index = index_new

    def values(self):
        return self.coll.values()

    def copy_from(self, x):
        self.clear()

        for value in x.values():
            item = self.add()
            for k, v in value.items():
                setattr(item, k, v)


# Preferences
# ------------------------------------------


def update_asset_asset_refresh(self, context):
    dynamic_list.asset_folder_list_refresh()
    dynamic_list.asset_list_refresh(hard=True)


class MYTHREEDAssetsPreferences(AddonPreferences):
    bl_idname = __package__

    # Asset
    # ------------------------

    use_custom_asset_asset_dir: BoolProperty(
        name="Use Custom Library Folder",
        description="Set custom asset library folder, if disabled the default library folder will be used",
        update=update_asset_asset_refresh,
    )
    custom_asset_asset_dir: StringProperty(
        name="Library Folder Path",
        description="Custom library folder path",
        subtype="DIR_PATH",
        update=update_asset_asset_refresh,
    )
    display_asset_asset_name: BoolProperty(
        name="Display Asset Name",
        description="Display asset name in Tool Shelf",
    )

    # Weighting
    # ------------------------

    weighting_hide_default_sets: BoolProperty(
        name="Hide Default Sets",
        description="Hide default MYTHREEDAssets sets from weighting sets menu",
        update=dynamic_list.weighting_set_refresh,
    )
    weighting_set_use_custom_dir: BoolProperty(
        name="Use Custom Library Folder",
        description="Set custom asset library folder, if disabled the default library folder will be used",
        update=dynamic_list.weighting_set_refresh,
    )
    weighting_set_custom_dir: StringProperty(
        name="Library Folder Path",
        description="Custom library folder path",
        subtype="DIR_PATH",
        update=dynamic_list.weighting_set_refresh,
    )

    # Themes
    # ------------------------

    theme_icon: EnumProperty(
        name="Icons",
        items=(
            ("LIGHT", "Light", ""),
            ("DARK", "Dark", ""),
        ),
    )
    view_font_size_option: IntProperty(
        name="Options",
        default=17,
        min=1,
    )
    view_font_size_distance: IntProperty(
        name="Distance",
        default=16,
        min=1,
    )

    def draw(self, context):
        props_wm = context.window_manager.mythreedassets
        active_tab = props_wm.prefs_active_tab

        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        split = layout.split(factor=0.25)
        col = split.column()
        col.use_property_split = False
        col.scale_y = 1.3
        col.prop(props_wm, "prefs_active_tab", expand=True)

        box = split.box()

        if active_tab == "ASSET_MANAGER":
            col = box.column()
            col.prop(self, "display_asset_asset_name")
            col.prop(self, "use_custom_asset_asset_dir")
            sub = col.row()
            sub.active = self.use_custom_asset_asset_dir
            sub.prop(self, "custom_asset_asset_dir")

# Window manager properties
# ------------------------------------------


def update_asset_asset_list(self, context):
    dynamic_list.asset_list_refresh()
    item_id = dynamic_list.assets(self, context)[0][0]

    if item_id:
        self.asset_list = item_id


class WmProperties(PropertyGroup):
    prefs_active_tab: EnumProperty(
        items=(
            ("ASSET_MANAGER",  "Asset Manager",  ""),
        ),
    )
    asset_folder: EnumProperty(
        name="Category",
        description="Asset category",
        items=dynamic_list.asset_folders,
        update=update_asset_asset_list,
    )
    asset_list: EnumProperty(items=dynamic_list.assets)
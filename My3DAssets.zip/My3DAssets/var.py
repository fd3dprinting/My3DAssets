# ##### BEGIN GPL LICENSE BLOCK #####
#
#  MYTHREEDAssets asset management toolkit for Blender.
#  Copyright (C) 2015-2019  Mikhail Rachinskiy + Paul Summers
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####


import os
import sys


ADDON_ID = __package__
ADDON_DIR = os.path.dirname(__file__)

ICONS_DIR = os.path.join(ADDON_DIR, "assets", "icons")

if sys.platform == "win32":
    LOCAL_PATH = os.getenv("LOCALAPPDATA")
elif sys.platform == "darwin":
    LOCAL_PATH = os.path.expanduser("~/Library/Application Support")
else:
    LOCAL_PATH = os.path.expanduser("~/.local/share")

USER_ASSET_DIR = os.path.join(ADDON_DIR, "assets")
USER_ASSET_DIR_OBJECT = os.path.join(USER_ASSET_DIR, "myobjects")

preview_collections = {}
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  MYTHREEDAssets asset management toolkit for Blender.
#  Copyright (C) 2015-2019  Mikhail Rachinskiy + Paul Summers
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####


bl_info = {
    "name": "My3DAssets",
    "author": "Mikhail Rachinskiy + Paul Summers",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "3D View > Sidebar",
    "description": "Object Asset Toolkit.",
    "wiki_url": "https://www.fluiddesigner.co.uk/",
    "tracker_url": "https://www.fluiddesigner.co.uk/",
    "category": "Object",
}


if "bpy" in locals():

    def walk(path, parent_dir=None):
        import importlib

        for entry in os.scandir(path):

            if entry.is_file() and entry.name.endswith(".py"):
                filename, _ = os.path.splitext(entry.name)
                is_init = filename == "__init__"

                if parent_dir:
                    module = parent_dir if is_init else f"{parent_dir}.{filename}"
                else:
                    if is_init:
                        continue
                    module = filename

                importlib.reload(eval(module))

            elif entry.is_dir() and not entry.name.startswith((".", "__")):
                dirname = f"{parent_dir}.{entry.name}" if parent_dir else entry.name
                walk(entry.path, parent_dir=dirname)

    walk(var.ADDON_DIR)

else:
    import os

    import bpy
    import bpy.utils.previews
    from bpy.props import PointerProperty

    from . import (
        var,
        ui,
        preferences,
        ops_asset,
    )
    from .lib import on_load

classes = (
    preferences.MYTHREEDAssetsPreferences,
    preferences.WmProperties,
    ui.VIEW3D_MT_mythreedassets_folder,
    ui.VIEW3D_MT_mythreedassets_asset,
    ui.VIEW3D_PT_mythreedassets_assets,
    ops_asset.WM_OT_asset_asset_folder_create,
    ops_asset.WM_OT_asset_asset_folder_rename,
    ops_asset.WM_OT_asset_asset_ui_refresh,
    ops_asset.WM_OT_asset_asset_add_to_library,
    ops_asset.WM_OT_asset_asset_remove_from_library,
    ops_asset.WM_OT_asset_asset_rename,
    ops_asset.WM_OT_asset_asset_replace,
    ops_asset.WM_OT_asset_asset_preview_replace,
    ops_asset.WM_OT_asset_asset_import,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.WindowManager.mythreedassets = PointerProperty(type=preferences.WmProperties)

    # Previews
    # ---------------------------

    pcoll = bpy.utils.previews.new()

    for entry in os.scandir(var.ICONS_DIR):
        if entry.is_file() and entry.name.endswith(".png"):
            name = os.path.splitext(entry.name)[0]
            pcoll.load(name.upper(), entry.path, "IMAGE")
        if entry.is_dir():
            for subentry in os.scandir(entry.path):
                if subentry.is_file() and subentry.name.endswith(".png"):
                    name = entry.name + os.path.splitext(subentry.name)[0]
                    pcoll.load(name.upper(), subentry.path, "IMAGE")

    var.preview_collections["icons"] = pcoll


def unregister():
    from .lib import dynamic_list, widget

    for cls in classes:
        bpy.utils.unregister_class(cls)

    del bpy.types.WindowManager.mythreedassets

    # Previews
    # ---------------------------

    for pcoll in var.preview_collections.values():
        bpy.utils.previews.remove(pcoll)

    var.preview_collections.clear()
    dynamic_list._cache.clear()



if __name__ == "__main__":
    register()

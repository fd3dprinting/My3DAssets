# ##### BEGIN GPL LICENSE BLOCK #####
#
#  MYTHREEDAssets asset management toolkit for Blender.
#  Copyright (C) 2015-2019  Mikhail Rachinskiy + Paul Summers
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####


import bpy
from bpy.types import Panel, Menu, UIList

from . import var
from .lib import asset


# Utils
# ---------------------------


class Setup:
    bl_category = "My3DAssets"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"

    def __init__(self):
        self.prefs = bpy.context.preferences.addons[__package__].preferences
        self.wm_props = bpy.context.window_manager.mythreedassets
        self.pcoll = var.preview_collections["icons"]
        self.theme = self.prefs.theme_icon

    def icon_get(self, name):
        return self.pcoll[self.theme + name].icon_id

# Menus
# ---------------------------

class VIEW3D_MT_mythreedassets_folder(Menu):
    bl_label = ""

    def draw(self, context):
        library_folder = asset.user_asset_asset_library_folder_object()
        layout = self.layout
        layout.operator("wm.mythreedassets_asset_asset_folder_create", icon="ADD")
        layout.operator("wm.mythreedassets_asset_asset_folder_rename", text="Rename")
        layout.separator()
        layout.operator("wm.path_open", text="Open Library Folder", icon="FILE_FOLDER").filepath = library_folder
        layout.separator()
        layout.operator("wm.mythreedassets_asset_asset_ui_refresh", icon="FILE_REFRESH")


class VIEW3D_MT_mythreedassets_asset(Menu):
    bl_label = ""

    def draw(self, context):
        layout = self.layout
        layout.operator("wm.mythreedassets_asset_asset_rename", text="Rename")
        layout.operator("wm.mythreedassets_asset_asset_replace")
        layout.operator("wm.mythreedassets_asset_asset_preview_replace", text="Replace Preview", icon="IMAGE_DATA")

# Panels

class VIEW3D_PT_mythreedassets_assets(Panel, Setup):
    bl_label = "Assets"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return context.mode in {"OBJECT", "EDIT_MESH"}

    def draw(self, context):
        layout = self.layout

        if not self.wm_props.asset_folder:
            layout.operator("wm.mythreedassets_asset_asset_folder_create", icon="ADD")
            layout.operator("wm.mythreedassets_asset_asset_ui_refresh", icon="FILE_REFRESH")
            return

        row = layout.row(align=True)
        row.prop(self.wm_props, "asset_folder", text="")
        row.menu("VIEW3D_MT_mythreedassets_folder", icon="THREE_DOTS")

        row = layout.row()

        col = row.column()
        col.enabled = bool(self.wm_props.asset_list)
        col.template_icon_view(self.wm_props, "asset_list", show_labels=True)

        if self.prefs.display_asset_asset_name:
            col.label(text=self.wm_props.asset_list)

        col = row.column(align=True)
        col.operator("wm.mythreedassets_asset_asset_add_to_library", text="", icon="ADD")
        col.operator("wm.mythreedassets_asset_asset_remove_from_library", text="", icon="REMOVE")
        col.separator()
        col.operator("view3d.mythreedassets_search_asset", text="", icon="VIEWZOOM")
        col.separator()
        col.menu("VIEW3D_MT_mythreedassets_asset", icon="DOWNARROW_HLT")

        layout.operator("wm.mythreedassets_asset_asset_import", text="Import Asset")
        layout.operator("wm.url_open", text="More Assets", icon='URL').url = "https://www.fluiddesigner.co.uk/"			


